
'use client';

import type {
  ReactNode,
} from 'react';


// ============================================================
// PROPS
//
// Sub-navigation is controlled by AppSidebar.
// AppHeader only owns:
//
// - page identity
// - page title/subtitle
// - optional right-side actions
// ============================================================

type Props = {

  activeTab: string;

  actions?: ReactNode;

};


// ============================================================
// HEADER CONTENT
// ============================================================

const TITLES: Record<
  string,
  {
    eyebrow: string;
    title: string;
    subtitle: string;
  }
> = {


  // ==========================================================
  // COMMAND CENTER
  // ==========================================================

  'CEO Summary': {

    eyebrow:
      'Command Center',

    title:
      'Business Overview',

    subtitle:
      'Revenue, media, customers and commerce in one place.',

  },


  // ==========================================================
  // META
  // ==========================================================

  'Meta OS': {

    eyebrow:
      'Meta OS',

    title:
      'Meta Growth Intelligence',

    subtitle:
      'Understand performance, efficiency and scaling opportunities.',

  },


  // ==========================================================
  // GOOGLE
  // ==========================================================

  'Google OS': {

    eyebrow:
      'Google OS',

    title:
      'Intent Intelligence',

    subtitle:
      'Understand how search demand converts into profitable growth.',

  },


  // ==========================================================
  // ATTRIBUTION
  // ==========================================================

  'Attribution OS': {

    eyebrow:
      'Attribution OS',

    title:
      'Customer Journey Intelligence',

    subtitle:
      'Understand the complete journey from discovery to purchase.',

  },


  // ==========================================================
  // RETENTION
  // ==========================================================

  'Retention OS': {

    eyebrow:
      'Retention OS',

    title:
      'Customer Retention Intelligence',

    subtitle:
      'Identify repeat behaviour, opportunities and next best actions.',

  },


  // ==========================================================
  // PRODUCT
  // ==========================================================

  'Product OS': {

    eyebrow:
      'Product OS',

    title:
      'Product Intelligence',

    subtitle:
      'Understand demand, inventory and SKU-level growth opportunities.',

  },

  // ==========================================================
  // SETTINGS
  // ==========================================================

  'Settings': {

    eyebrow:
      'Growth OS',

    title:
      'Settings',

    subtitle:
      'Configure tools, integrations, rules, access and plans.',

  },

};


// ============================================================
// APP HEADER
// ============================================================

export default function AppHeader({

  activeTab,

  actions,

}: Props) {


  const content =
    TITLES[
      activeTab
    ]
    ||
    TITLES[
      'CEO Summary'
    ];


  return (

    <header
      className="
        sticky
        top-0
        z-40

        border-b
        border-slate-200/80

        bg-white/95

        backdrop-blur-xl
      "
    >


      <div
        className="
          flex
          min-h-[60px]

          items-center
          justify-between

          gap-3

          px-3

          xl:px-3
        "
      >


        {/* ===================================================
            PAGE IDENTITY
        =================================================== */}

        <div className="min-w-0">


          <div
            className="
              text-[9px]
              font-semibold
              uppercase
              tracking-[0.18em]

              text-violet-600
            "
          >
            {content.eyebrow}
          </div>


          <h1
            className="
              mt-0.5

              truncate

              text-[18px]
              font-semibold

              tracking-[-0.035em]

              text-slate-950
            "
          >
            {content.title}
          </h1>


          <p
            className="
              mt-0.5

              hidden

              text-[11px]

              text-slate-400

              xl:block
            "
          >
            {content.subtitle}
          </p>


        </div>


        {/* ===================================================
            RIGHT-SIDE ACTIONS

            Examples:
            - date control
            - refresh
            - future contextual actions
        =================================================== */}

        {actions && (

          <div className="ml-auto shrink-0">

            {actions}

          </div>

        )}


      </div>


    </header>

  );

}
