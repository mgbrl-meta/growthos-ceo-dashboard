'use client';

import {
  useEffect,
  useState,
} from 'react';

import {
  AlertCircle,
  CheckCircle2,
  ClipboardCheck,
  RefreshCw,
} from 'lucide-react';


type ReadinessCheck = {
  id: string;
  category: string;
  label: string;
  status: 'pass' | 'warning' | 'pending' | 'blocker';
  detail: string;
};


type ReadinessResponse = {
  ok: boolean;
  error?: string;
  message?: string;
  readiness?: {
    status: 'ready' | 'needs_live_qa' | 'blocked';
    checks: ReadinessCheck[];
    summary: {
      pass: number;
      warning: number;
      pending: number;
      blocker: number;
    };
  };
};


function statusClasses(
  status:
    ReadinessCheck['status']
) {

  if (
    status ===
      'pass'
  ) {
    return 'border-emerald-200 bg-emerald-50 text-emerald-800';
  }

  if (
    status ===
      'blocker'
  ) {
    return 'border-red-200 bg-red-50 text-red-800';
  }

  if (
    status ===
      'warning'
  ) {
    return 'border-amber-200 bg-amber-50 text-amber-800';
  }

  return 'border-sky-200 bg-sky-50 text-sky-800';

}


export default function CommercialReadinessSettings() {

  const [
    response,
    setResponse,
  ] =
    useState<ReadinessResponse | null>(
      null
    );

  const [
    loading,
    setLoading,
  ] =
    useState(true);

  const [
    error,
    setError,
  ] =
    useState('');


  async function load() {

    try {

      setLoading(true);
      setError('');

      const result =
        await fetch(
          '/api/workspace/commercial-readiness',
          {
            cache:
              'no-store',
            credentials:
              'same-origin',
          }
        );

      const json =
        await result.json();

      if (
        !result.ok
        ||
        !json?.ok
      ) {

        throw new Error(
          json?.message
          ||
          json?.error
          ||
          'Unable to evaluate commercial readiness'
        );

      }

      setResponse(
        json
      );

    } catch (
      error:
        any
    ) {

      setError(
        String(
          error?.message
          ||
          'Unable to evaluate commercial readiness'
        )
      );

    } finally {

      setLoading(false);

    }

  }


  useEffect(
    () => {
      load();
    },
    []
  );


  const readiness =
    response?.readiness;


  if (loading) {

    return (
      <div className="gos-panel p-5 text-sm text-slate-500">
        Evaluating commercial readiness...
      </div>
    );

  }


  if (
    error
    ||
    !readiness
  ) {

    return (
      <div className="gos-panel p-5">
        <p className="text-sm font-semibold text-red-700">
          {error || 'Commercial readiness is unavailable.'}
        </p>

        <button
          type="button"
          onClick={load}
          className="mt-3 rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold"
        >
          Retry
        </button>
      </div>
    );

  }


  const headline =
    readiness.status ===
      'ready'
      ? 'Ready'
      : readiness.status ===
          'blocked'
        ? 'Blocked'
        : 'Needs Live QA';


  return (

    <div className="space-y-3">

      <section className="gos-panel !p-4">

        <div className="flex items-start justify-between gap-3">

          <div className="flex items-start gap-3">

            <div className="rounded-xl bg-violet-50 p-2.5 text-violet-700">
              <ClipboardCheck size={16} />
            </div>

            <div>
              <h2 className="text-[14px] font-semibold text-slate-950">
                Commercial Readiness
              </h2>
              <p className="mt-0.5 text-[9px] text-slate-500">
                Automated launch checks plus explicit visibility into what still requires live production QA.
              </p>
            </div>

          </div>

          <button
            type="button"
            onClick={load}
            className="rounded-lg border border-slate-200 p-2 text-slate-500 hover:bg-slate-50"
            title="Run checks again"
          >
            <RefreshCw size={14} />
          </button>

        </div>

      </section>


      <section className="gos-panel !p-4">

        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">

          <div>
            <p className="text-[8px] font-semibold uppercase tracking-wide text-slate-400">
              Go-Live Status
            </p>
            <h3 className="mt-1 text-[20px] font-bold tracking-tight text-slate-950">
              {headline}
            </h3>
          </div>

          <div className="grid grid-cols-4 gap-2">

            <Metric label="Pass" value={readiness.summary.pass} />
            <Metric label="Warning" value={readiness.summary.warning} />
            <Metric label="Pending" value={readiness.summary.pending} />
            <Metric label="Blocker" value={readiness.summary.blocker} />

          </div>

        </div>

        <p className="mt-3 text-[9px] leading-4 text-slate-500">
          Automated checks cannot prove a real Shopify embedded launch, provider approval, callback or payment. Those remain explicit live QA gates.
        </p>

      </section>


      <section className="gos-panel !p-4">

        <h3 className="gos-section-title">
          Launch Checks
        </h3>

        <div className="mt-3 space-y-2">

          {readiness.checks.map(
            check => (

              <div
                key={check.id}
                className="flex items-start gap-3 rounded-xl border border-slate-100 p-3"
              >

                <div
                  className={`mt-0.5 rounded-lg border p-1.5 ${statusClasses(check.status)}`}
                >
                  {check.status === 'pass'
                    ? <CheckCircle2 size={13} />
                    : <AlertCircle size={13} />}
                </div>

                <div className="min-w-0 flex-1">

                  <div className="flex flex-wrap items-center gap-2">

                    <p className="text-[10px] font-semibold text-slate-900">
                      {check.label}
                    </p>

                    <span className={`rounded-full border px-2 py-0.5 text-[7px] font-semibold uppercase ${statusClasses(check.status)}`}>
                      {check.status}
                    </span>

                    <span className="text-[7px] font-semibold uppercase tracking-wide text-slate-400">
                      {check.category}
                    </span>

                  </div>

                  <p className="mt-1 text-[8px] leading-4 text-slate-500">
                    {check.detail}
                  </p>

                </div>

              </div>

            )
          )}

        </div>

      </section>

    </div>

  );

}


function Metric({
  label,
  value,
}: {
  label: string;
  value: number;
}) {

  return (
    <div className="min-w-[64px] rounded-xl border border-slate-100 bg-slate-50 px-3 py-2 text-center">
      <p className="text-[14px] font-bold text-slate-950">
        {value}
      </p>
      <p className="text-[7px] font-semibold uppercase text-slate-400">
        {label}
      </p>
    </div>
  );

}
