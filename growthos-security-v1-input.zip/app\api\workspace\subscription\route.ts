import {
  NextRequest,
  NextResponse,
} from 'next/server';

import {
  authenticateRequest,
} from '@/lib/auth/request-auth';

import {
  getGrowthOSWorkspaceSubscriptionSnapshot,
} from '@/lib/admin/control-plane';


export const dynamic =
  'force-dynamic';

export const runtime =
  'nodejs';


// ============================================================
// CURRENT WORKSPACE SUBSCRIPTION
//
// FAST RUNTIME READ.
//
// IMPORTANT:
//
// This endpoint does NOT:
//
// - ensure schema
// - create tables
// - seed plans
// - seed modules
// - run migrations
//
// Tenant comes exclusively from authenticated session.
// ============================================================

export async function GET(
  request: NextRequest
) {

  const startedAt =
    Date.now();


  try {

    // ========================================================
    // 1. AUTHENTICATE
    // ========================================================

    const identity =
      await authenticateRequest(
        request
      );


    if (!identity) {

      return NextResponse.json(
        {

          ok:
            false,

          error:
            'UNAUTHENTICATED',

        },
        {
          status:
            401,
        }
      );

    }


    // ========================================================
    // 2. ACTIVE TENANT
    // ========================================================

    const workspaceId =
      String(
        identity.workspaceId
        ||
        ''
      ).trim();


    const brandId =
      String(
        identity.brandId
        ||
        ''
      ).trim();


    if (
      !workspaceId
      ||
      !brandId
    ) {

      return NextResponse.json(
        {

          ok:
            false,

          error:
            'ACTIVE_BRAND_REQUIRED',

        },
        {
          status:
            400,
        }
      );

    }


    // ========================================================
    // 3. ONE CONTROL-PLANE QUERY
    // ========================================================

    const snapshot =
      await getGrowthOSWorkspaceSubscriptionSnapshot(
        workspaceId,
        brandId
      );


    // ========================================================
    // 4. RESPONSE
    // ========================================================

    return NextResponse.json({

      ok:
        true,

      ...snapshot,

      meta: {

        durationMs:
          Date.now()
          -
          startedAt,

      },

    });

  } catch (
    error: any
  ) {

    const message =
      String(
        error?.message
        ||
        'Unable to load workspace subscription'
      );


    console.error(
      'WORKSPACE_SUBSCRIPTION_ERROR',
      {
        message,

        durationMs:
          Date.now()
          -
          startedAt,
      }
    );


    return NextResponse.json(
      {

        ok:
          false,

        error:
          'Unable to load subscription',

        meta: {

          durationMs:
            Date.now()
            -
            startedAt,

        },

      },
      {
        status:
          500,
      }
    );

  }

}