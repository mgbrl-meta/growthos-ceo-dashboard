'use client';

import {
  useEffect,
  useState,
} from 'react';

import {
  CreditCard,
  ExternalLink,
  RefreshCw,
  Save,
} from 'lucide-react';

type SubscriptionContext = any;

type BillingSnapshot = {
  ok: boolean;
  billingAccount: any | null;
  billingProfile: any | null;
  invoices: any[];
  latestMigration: any | null;
  providerSetup: {
    razorpay: boolean;
    shopify: boolean;
  };
  shopify: {
    installed: boolean;
    shopDomain: string | null;
    shopId: string | null;
  };
  error?: string;
};

type ProfileDraft = {
  legalBusinessName: string;
  gstin: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  invoiceEmail: string;
};

const EMPTY_PROFILE: ProfileDraft = {
  legalBusinessName: '',
  gstin: '',
  addressLine1: '',
  addressLine2: '',
  city: '',
  state: '',
  postalCode: '',
  country: 'IN',
  invoiceEmail: '',
};

function pretty(value: unknown) {
  return String(value || '—')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, letter => letter.toUpperCase());
}

function formatDate(value: unknown) {
  if (!value) return '—';
  const date = new Date(String(value));
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleDateString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
  });
}

function formatLimit(value: number | null | undefined) {
  if (value === null || value === undefined) return 'Unlimited';
  return Number(value).toLocaleString('en-IN');
}

export default function BillingSettingsV1({
  subscriptionContext,
  loading,
  error,
  reload,
}: {
  subscriptionContext: SubscriptionContext | null;
  loading: boolean;
  error: string | null;
  reload: () => void;
}) {
  const [billing, setBilling] = useState<BillingSnapshot | null>(null);
  const [billingLoading, setBillingLoading] = useState(true);
  const [billingError, setBillingError] = useState('');
  const [actionSaving, setActionSaving] = useState(false);
  const [profileSaving, setProfileSaving] = useState(false);
  const [profile, setProfile] = useState<ProfileDraft>(EMPTY_PROFILE);
  const [notice, setNotice] = useState('');

  async function loadBilling() {
    setBillingLoading(true);
    setBillingError('');
    try {
      const response = await fetch('/api/workspace/billing', {
        cache: 'no-store', credentials: 'same-origin',
      });
      const json = await response.json();
      if (!response.ok || !json?.ok) throw new Error(json?.message || json?.error || 'Unable to load billing');
      setBilling(json);
      const p = json.billingProfile || {};
      setProfile({
        legalBusinessName: p.legalBusinessName || '',
        gstin: p.gstin || '',
        addressLine1: p.addressLine1 || '',
        addressLine2: p.addressLine2 || '',
        city: p.city || '',
        state: p.state || '',
        postalCode: p.postalCode || '',
        country: p.country || 'IN',
        invoiceEmail: p.invoiceEmail || '',
      });
    } catch (err: any) {
      setBillingError(String(err?.message || 'Unable to load billing'));
    } finally {
      setBillingLoading(false);
    }
  }

  useEffect(() => {
    loadBilling();
  }, []);

  async function billingAction(action: string) {
    setActionSaving(true);
    setNotice('');
    setBillingError('');
    try {
      const response = await fetch('/api/workspace/billing', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, planId: subscriptionContext?.plan?.planId }),
      });
      const json = await response.json();
      if (!response.ok || !json?.ok) throw new Error(json?.message || json?.error || 'Billing action failed');

      if (json.checkoutUrl || json.url) {
        window.location.assign(json.checkoutUrl || json.url);
        return;
      }

      setNotice(
        action === 'cancel'
          ? 'Cancellation scheduled with the billing provider.'
          : action === 'refresh_invoices'
            ? 'Invoice history refreshed.'
            : 'Billing updated.'
      );
      await loadBilling();
      reload();
    } catch (err: any) {
      setBillingError(String(err?.message || 'Billing action failed'));
    } finally {
      setActionSaving(false);
    }
  }

  async function saveProfile() {
    setProfileSaving(true);
    setNotice('');
    setBillingError('');
    try {
      const response = await fetch('/api/workspace/billing/profile', {
        method: 'PATCH',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profile),
      });
      const json = await response.json();
      if (!response.ok || !json?.ok) throw new Error(json?.error || 'Unable to save billing profile');
      setNotice('Billing profile saved.');
      await loadBilling();
    } catch (err: any) {
      setBillingError(String(err?.message || 'Unable to save billing profile'));
    } finally {
      setProfileSaving(false);
    }
  }

  if (loading || billingLoading) {
    return <section className="gos-panel !p-4 text-[10px] text-slate-500">Loading Plan & Billing...</section>;
  }

  if (error || !subscriptionContext?.configured || !subscriptionContext?.plan || !subscriptionContext?.subscription) {
    return (
      <section className="gos-panel !p-4">
        <h3 className="gos-section-title">Plan & Billing</h3>
        <p className="mt-2 text-[10px] text-slate-500">
          {error || 'A Growth OS commercial plan has not been assigned to this brand yet.'}
        </p>
      </section>
    );
  }

  const account = billing?.billingAccount;
  const plan = subscriptionContext.plan;
  const subscription = subscriptionContext.subscription;
  const channel = account?.channel || 'unconfigured';
  const provider = account?.provider || 'none';

  return (
    <div className="space-y-3">
      <section className="gos-panel !p-3.5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <CreditCard size={16} className="text-violet-600" />
              <h2 className="gos-section-title">Plan & Billing</h2>
            </div>
            <p className="mt-1 text-[9px] leading-4 text-slate-500">
              One Growth OS subscription, with Shopify or Direct billing as the payment rail.
            </p>
          </div>
          <button type="button" onClick={loadBilling} disabled={billingLoading} className="inline-flex h-8 items-center gap-1.5 rounded-[8px] border border-slate-200 bg-white px-3 text-[9px] font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50">
            <RefreshCw size={12} /> Refresh
          </button>
        </div>
      </section>

      {(billingError || notice) && (
        <section className={`rounded-[9px] border p-3 text-[9px] ${billingError ? 'border-red-200 bg-red-50 text-red-700' : 'border-emerald-200 bg-emerald-50 text-emerald-700'}`}>
          {billingError || notice}
        </section>
      )}

      <section className="grid grid-cols-2 gap-2 xl:grid-cols-4">
        <Metric label="Current Plan" value={plan.name} />
        <Metric label="Monthly Orders" value={formatLimit(plan.effectiveMonthlyOrderLimit)} />
        <Metric label="Billing Channel" value={pretty(channel)} />
        <Metric label="Billing Status" value={pretty(account?.status || subscription.status)} />
      </section>

      <section className="gos-panel !p-3.5">
        <h3 className="gos-section-title">Subscription</h3>
        <div className="mt-3 grid grid-cols-1 gap-2 md:grid-cols-2 xl:grid-cols-3">
          <Value label="Growth OS Plan ID" value={plan.planId} mono />
          <Value label="Provider" value={pretty(provider)} />
          <Value label="External Plan" value={account?.externalPlanId || 'Not mapped'} mono />
          <Value label="Billing Cycle" value={pretty(account?.billingCycle)} />
          <Value label="Current Period End" value={formatDate(account?.currentPeriodEnd)} />
          <Value label="Cancel at Period End" value={account?.cancelAtPeriodEnd ? 'Yes' : 'No'} />
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          {channel === 'shopify' && (
            <button type="button" disabled={actionSaving || !billing?.providerSetup.shopify} onClick={() => billingAction('shopify_manage_url')} className="inline-flex h-8 items-center gap-1.5 rounded-[8px] bg-slate-950 px-3 text-[9px] font-semibold text-white disabled:opacity-40">
              Manage in Shopify <ExternalLink size={11} />
            </button>
          )}

          {(channel === 'unconfigured' || channel === 'direct') && !account?.externalSubscriptionId && (
            <button type="button" disabled={actionSaving || !billing?.providerSetup.razorpay} onClick={() => billingAction('start_direct_checkout')} className="h-8 rounded-[8px] bg-slate-950 px-3 text-[9px] font-semibold text-white disabled:opacity-40">
              Start Direct Billing
            </button>
          )}

          {account?.provider === 'razorpay' && account?.externalSubscriptionId && (
            <button type="button" disabled={actionSaving} onClick={() => billingAction('refresh_invoices')} className="h-8 rounded-[8px] border border-slate-200 bg-white px-3 text-[9px] font-semibold text-slate-700 disabled:opacity-40">
              Refresh Invoices
            </button>
          )}

          {account?.status === 'active' && !account?.cancelAtPeriodEnd && (
            <button type="button" disabled={actionSaving} onClick={() => {
              if (window.confirm('Cancel this subscription at the end of the current billing cycle?')) billingAction('cancel');
            }} className="h-8 rounded-[8px] border border-red-200 bg-white px-3 text-[9px] font-semibold text-red-700 disabled:opacity-40">
              Cancel Subscription
            </button>
          )}
        </div>

        {!billing?.providerSetup.razorpay && channel !== 'shopify' && (
          <p className="mt-3 text-[9px] text-amber-700">Direct billing is waiting for Razorpay API credentials.</p>
        )}
        {!billing?.providerSetup.shopify && billing?.shopify.installed && (
          <p className="mt-3 text-[9px] text-amber-700">Shopify App Pricing is waiting for Partner API billing credentials.</p>
        )}
      </section>

      {billing?.latestMigration && (
        <section className="gos-panel !p-3.5">
          <h3 className="gos-section-title">Billing Migration</h3>
          <div className="mt-3 grid grid-cols-1 gap-2 md:grid-cols-3">
            <Value label="From" value={pretty(billing.latestMigration.fromChannel)} />
            <Value label="To" value={pretty(billing.latestMigration.toChannel)} />
            <Value label="Status" value={pretty(billing.latestMigration.status)} />
          </div>
          {billing.latestMigration.failureReason && <p className="mt-2 text-[9px] text-red-700">{billing.latestMigration.failureReason}</p>}
        </section>
      )}

      <section className="gos-panel !p-3.5">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h3 className="gos-section-title">Billing Profile</h3>
            <p className="mt-1 text-[9px] text-slate-500">Used for direct Growth OS billing and GST records. Shopify billing remains invoiced by Shopify.</p>
          </div>
          <button type="button" onClick={saveProfile} disabled={profileSaving} className="inline-flex h-8 items-center gap-1.5 rounded-[8px] bg-slate-950 px-3 text-[9px] font-semibold text-white disabled:opacity-40">
            <Save size={11} /> {profileSaving ? 'Saving...' : 'Save Profile'}
          </button>
        </div>

        <div className="mt-3 grid grid-cols-1 gap-2 md:grid-cols-2">
          <Field label="Legal Business Name" value={profile.legalBusinessName} onChange={value => setProfile(p => ({ ...p, legalBusinessName: value }))} />
          <Field label="GSTIN" value={profile.gstin} onChange={value => setProfile(p => ({ ...p, gstin: value.toUpperCase() }))} />
          <Field label="Invoice Email" value={profile.invoiceEmail} onChange={value => setProfile(p => ({ ...p, invoiceEmail: value }))} />
          <Field label="Country" value={profile.country} onChange={value => setProfile(p => ({ ...p, country: value.toUpperCase() }))} />
          <Field label="Address Line 1" value={profile.addressLine1} onChange={value => setProfile(p => ({ ...p, addressLine1: value }))} />
          <Field label="Address Line 2" value={profile.addressLine2} onChange={value => setProfile(p => ({ ...p, addressLine2: value }))} />
          <Field label="City" value={profile.city} onChange={value => setProfile(p => ({ ...p, city: value }))} />
          <Field label="State" value={profile.state} onChange={value => setProfile(p => ({ ...p, state: value }))} />
          <Field label="Postal Code" value={profile.postalCode} onChange={value => setProfile(p => ({ ...p, postalCode: value }))} />
        </div>
      </section>

      <section className="gos-panel !p-3.5">
        <div className="flex items-center justify-between">
          <h3 className="gos-section-title">Invoices</h3>
          <span className="text-[8px] text-slate-400">{billing?.invoices?.length || 0} loaded</span>
        </div>
        <div className="mt-3 space-y-2">
          {(billing?.invoices || []).length === 0 ? (
            <p className="text-[9px] text-slate-500">No direct-billing invoices have been synced yet. Shopify charges remain on the merchant's Shopify invoice.</p>
          ) : billing!.invoices.map(invoice => (
            <div key={invoice.invoiceId} className="flex items-center justify-between rounded-[8px] border border-slate-200 bg-white p-2.5 text-[9px]">
              <div>
                <div className="font-semibold text-slate-800">{invoice.externalInvoiceId}</div>
                <div className="mt-0.5 text-slate-500">{formatDate(invoice.invoiceDate)} · {pretty(invoice.status)}</div>
              </div>
              {invoice.invoiceUrl && <a href={invoice.invoiceUrl} target="_blank" rel="noreferrer" className="font-semibold text-violet-600">Open</a>}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return <section className="gos-panel !p-3"><div className="text-[8px] font-semibold uppercase tracking-[0.12em] text-slate-400">{label}</div><div className="mt-1 text-[13px] font-semibold text-slate-950">{value}</div></section>;
}

function Value({ label, value, mono = false }: { label: string; value: string; mono?: boolean }) {
  return <div className="rounded-[8px] border border-slate-200 bg-slate-50 p-2.5"><div className="text-[8px] font-semibold uppercase tracking-[0.1em] text-slate-400">{label}</div><div className={`mt-1 text-[9px] font-semibold text-slate-700 ${mono ? 'font-mono' : ''}`}>{value || '—'}</div></div>;
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  return <label className="block"><span className="mb-1 block text-[8px] font-semibold uppercase tracking-[0.1em] text-slate-400">{label}</span><input value={value} onChange={event => onChange(event.target.value)} className="gos-input w-full" /></label>;
}
